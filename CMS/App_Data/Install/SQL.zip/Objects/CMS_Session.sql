SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Session](
	[SessionIdentificator] [nvarchar](50) NOT NULL,
	[SessionUserID] [int] NULL,
	[SessionLocation] [nvarchar](450) NULL,
	[SessionLastActive] [datetime2](7) NOT NULL,
	[SessionLastLogon] [datetime2](7) NULL,
	[SessionExpires] [datetime2](7) NOT NULL,
	[SessionExpired] [bit] NOT NULL,
	[SessionSiteID] [int] NULL,
	[SessionUserIsHidden] [bit] NOT NULL,
	[SessionFullName] [nvarchar](450) NULL,
	[SessionEmail] [nvarchar](254) NULL,
	[SessionUserName] [nvarchar](254) NULL,
	[SessionNickName] [nvarchar](254) NULL,
	[SessionUserCreated] [datetime2](7) NULL,
	[SessionContactID] [int] NULL,
	[SessionID] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_CMS_Session] PRIMARY KEY CLUSTERED 
(
	[SessionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON),
 CONSTRAINT [IX_CMS_Session_SessionIdentificator] UNIQUE NONCLUSTERED 
(
	[SessionIdentificator] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_Session_SessionSiteID] ON [dbo].[CMS_Session]
(
	[SessionSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Session_SessionUserID] ON [dbo].[CMS_Session]
(
	[SessionUserID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Session_SessionUserIsHidden] ON [dbo].[CMS_Session]
(
	[SessionUserIsHidden] ASC
)
GO
ALTER TABLE [dbo].[CMS_Session] ADD  CONSTRAINT [DEFAULT_CMS_Session_SessionIdentificator]  DEFAULT (N'') FOR [SessionIdentificator]
GO
ALTER TABLE [dbo].[CMS_Session] ADD  CONSTRAINT [DEFAULT_CMS_Session_SessionLastActive]  DEFAULT ('9/9/2008 3:44:26 PM') FOR [SessionLastActive]
GO
ALTER TABLE [dbo].[CMS_Session] ADD  CONSTRAINT [DEFAULT_CMS_Session_SessionExpires]  DEFAULT ('9/9/2008 3:45:44 PM') FOR [SessionExpires]
GO
ALTER TABLE [dbo].[CMS_Session] ADD  CONSTRAINT [DEFAULT_CMS_Session_SessionExpired]  DEFAULT ((0)) FOR [SessionExpired]
GO
ALTER TABLE [dbo].[CMS_Session]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Session_SessionSiteID_CMS_Site] FOREIGN KEY([SessionSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_Session] CHECK CONSTRAINT [FK_CMS_Session_SessionSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_Session]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Session_SessionUserID_CMS_User] FOREIGN KEY([SessionUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_Session] CHECK CONSTRAINT [FK_CMS_Session_SessionUserID_CMS_User]
GO
